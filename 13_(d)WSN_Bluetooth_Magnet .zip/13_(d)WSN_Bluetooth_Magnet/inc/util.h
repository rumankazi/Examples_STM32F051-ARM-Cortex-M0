#ifndef _UTIL_H
#define _UTIL_H
#include <stdint.h>

void int_to_str(uint32_t num, uint32_t digits, char* buffer, uint32_t buffer_size);

#endif
